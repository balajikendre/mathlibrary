					"math.h"



This project is mathematics library  (math.h).

Various mathematical functions are defined and described here ->

	fabs -> gives absolute value of given nimber
	floor -> gives greatest integer below or equal to given number
	ceil -> gives smallest integer bigger or equal to given number
	round -> rounds off the given number to the closest integer
	sqrt -> gives square root of given number
	pow -> gives value of a number raised to power of second
	fact -> gives value of the factorial of the given number
	exp ->  gives the exponential value of number
	log-> gives the natural logarithm of x to the base e
	log10 -> gives the logarithmic value of x to the base 10
	sin -> gives value of sine of the angle in radians
	cos -> gives value of cosine of the angle in radians	
	tan -> gives value of tangent of the angle in radians
	sinh -> gives value of hyperbolic sine of x
	cosh -> gives value of hyperbolic cosine of x
	tanh -> gives value of hyperbolic tangent of x
	asin -> gives value of the arc sin of x
	acos -> gives value of the arc cos of x
	atan -> gives value of the arc tan of x
	atan2 -> gives value of the arc tan of (x / y)
	fmod -> gives value of remainder of (x / y)
	ldexp -> gives value of product of x and 2 raised to the power of given exponent
	modf -> gives value of fraction part of given x
	frexp -> gives value of mantissa and int pointer to exponent


This project has been done by:-
	Name : Kendre Balaji Dnyanoba
	MIS : 111503031
	Class : SY Comp
	Batch : S2
