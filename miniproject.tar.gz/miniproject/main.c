#include<stdio.h>
#include"math.h"
#include<stdlib.h>
#include<string.h>
#include<errno.h>
int main() {
	FILE *fp;
	char *a[32], *p;
	double x, y, z;
	fp = fopen("test.txt", "r");
	if(fp == NULL) {
		printf("can't open file\n");
		return errno;
	}
	p = (char *)malloc(128);
	a[0] = "pow";
	a[1] = "fabs";
	a[2] = "floor";
	a[3] = "ceil";
	a[4] = "roundn";
	a[5] = "sqrt";
	a[6] = "exp";
	a[7] = "log";
	a[8] = "log10";
	a[9] = "sin";
	a[10] = "cos";
	a[11] = "tan";
	a[12] = "sinh";
	a[13] = "cosh";
	a[14] = "tanh";
	a[15] = "asin";
	a[16] = "acos";
	a[17] = "atan";
	a[18] = "fmod";
	a[19] = "ldexp";
	a[20] = "modf";
	a[21] = "frexp";
	a[22] = "atan2";


	while(!feof(fp)) {
		fscanf(fp, "%s", p);

		if(strcmp(p, a[0]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf%lf", &x, &y, &z);
			double t = pow(x, y);
			if(t == z)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[1]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = fabs(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[2]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = floor(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[3]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = ceil(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[4]) == 0) {
			free(p);
			int a;
			fscanf(fp, "%lf%d", &x, &a);
			int t = roundn(x);
			if(t == a)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %d\n", t);
		}

		if(strcmp(p, a[5]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = sqrt(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[6]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = exp(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[7]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = log(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[8]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = log10(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[9]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = sin(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[10]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = cos(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[11]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = tan(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[12]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = sinh(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[13]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = cosh(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[14]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = tanh(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[15]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = asin(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}


		if(strcmp(p, a[16]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = acos(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[17]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf", &x, &y);
			double t = atan(x);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[22]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf%lf", &x, &y, &z);
			double t = atan2(x, y);
			if(t == z)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[18]) == 0) {
			free(p);
			fscanf(fp, "%lf%lf%lf", &x, &y, &z);
			double t = fmod(x, y);
			if(t == z)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[19]) == 0) {
			free(p);
			int a;
			fscanf(fp, "%lf%d%lf", &x, &a, &y);
			double t = ldexp(x, a);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[20]) == 0) {
			free(p);
			double a;
			fscanf(fp, "%lf%lf", &x, &y);
			double t = modf(x, &a);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}

		if(strcmp(p, a[21]) == 0) {
			free(p);
			int a;
			fscanf(fp, "%lf%lf", &x, &y);
			double t = frexp(x, &a);
			if(t == y)
				printf("operation successful\n");
			else
				printf("operation failed because answer is %lf\n", t);
		}


		p = (char *)malloc(128);
	}
	return 0;
}
