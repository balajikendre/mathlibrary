#include <stdio.h>
#include "math.h"
#define PI 3.14159265
#define E 2.3025850929940

/*This function returns absolute value of the given number */
double fabs(double x) {
	if (x >= 0.00)
		return x;
	else 
		return (-x);
}

/* This function returns largest integral value less than x. */
double floor(double x) {
	int y = (int) x;
	double p;
	if(x >= 0) {
		p = y;
	}	
	if((x < 0) && (y > x)) {
		p = --y;
	}
	else if((x < 0) && (x = y)) {
		p = y;
	}
	return p;
}

/* This function returns smallest integral value that exceeds x. */
double ceil(double x) {
	int y = (int) x;
	double p;
	if((x >= 0) && (y < x))
		p = ++y;
	else if((x >= 0) && (y == x))
		p = y;
	if(x < 0)
		p = y;
	return p;
}

/* this fuction returns rounding of value of given double value. */
int roundn(double x) {
	if(x < 0.0)
		return (x - 0.5);
	else
		return (x + 0.5);
}

/*This function returns the squareroot of given positive number */
double sqrt(double x) {
	if (x < 0.00000000) {
		printf("input is invalid");
		return -1;
	}
	double low, high = x, b;
	double m;
	int i;
	low = 0.0000;
	m = (low + high) / 2;
	for (i = 0; i <= 128; i++) {
		b = m * m;
		if(b == x) {
	        	return m;
	           	break;
	        } 
		else {
	        	if(m * m > x) {
	        		high = m;
	                	m = (low + high) / 2;
	           	} 
			else {
               			low = m;
               			m = (low + high) / 2;
            		}
         	}
      	}
	return m;
}

/* This function returns the value of x raised to the power of y */
double pow(double x, double y) {
	int sign, i;
	double prod = 1;
	if(y == 0) { 	
		if(x == 0) {
			printf("Bad input \n");
			return -1;
		}
	}
	if(y < 0) {
		sign = -1;
		y = -y;
	}
	for(i=0; i<y; i++) {
		prod = prod * x;
	}
	if(sign == -1)
		prod = 1.0/prod;
	return prod;
}

/* This function returns the exponential value of number */
double exp(double x) {
	double ex = 1;
	double term = 1;
	int n = 1;
	while (!(term >= -0.001 && term <= 0.001)) {
		term = (term * x) / n;
		ex += term;
		n++;
	}	
	return ex;
}

/* This function returns the natural logarithm of x  */
double log(double x) {
	if (x <= 0.00000000) {
		printf("input is invalid ");
		return -1;
	}
	double y;
	y = (x - 1)/(x + 1);
	double sum;
	sum = 0.0000;
	double denominator = 1.0;
	double numerator = y;
	double term = numerator / denominator;
	while(term > 0.000001) {
		sum += term;
		denominator += 2.0;
		numerator = numerator * y * y;
		term = numerator / denominator;
	}
	return (2.0 * sum);
}

/* This fuction returns the logarithmic value of x to the base 10 */
double log10(double x) {
	if (x <= 0.00000000) {
		printf("input is invalid ");
		return -1; 
	}
	else {
		double l;
		l = log(x);
		return (l / E);
	}
}

/* This function returns sine of the angle x */
double sin(double x) {
	int n = 1;
	double sin = x, term = x;
	while (!(term >= -0.0000000001 && term <= 0.000000001)) {
		term = (-term) * (x * x) / ((2 * n + 1) * (2 * n));
		sin += term;	
		n++;
	}
	return sin;
}

/* This function returns cosine of the angle x */
double cos(double x) {
	int n = 1;
	double cos, term;
	cos = 1;	
	term = 1;
	while (!(term >= -0.0000000001 && term <= 0.000000001)) {
		term = (-term) * (x * x) / ((2 * n - 1) * (2 * n));
		cos += term;	
		n++;
	}
	return cos;
}

/* This function returns tan of the angle x */
double tan(double x) {
	double tan;
	if(cos(x) == 0) {
		printf("tan value is infnite ");
		return -1;
	}
	tan = sin(x) / cos(x);
	return tan;
}

/* This function returns hyperbolic sine of x */
double sinh(double x) {
	int n = 1;
	double sinh = x, term = x;
	while (!(term >= -0.0000000001 && term <= 0.000000001)) {
		term = (term) * (x * x) / ((2 * n + 1) * (2 * n));
		sinh += term;	
		n++;
	}
	return sinh;
}

/* This function returns hyperbolic cos of x */
double cosh(double x) {
	int n = 1;
	double cosh = 1, term = 1;
	while (!(term >= -0.0000000001 && term <= 0.000000001)) {
		term = (term) * (x * x) / ((2 * n - 1) * (2 * n));
		cosh += term;	
		n++;
	}
	return cosh;
}

/* This function returns hyperbolic tan of x */
double tanh(double x) {
	double tanh;
	if(cosh(x) == 0) {
		printf("tan value is infnite ");
		return -1;
	}
	tanh =	sinh(x) / cosh(x);
	return tanh;
}

/*This function returns the arc sin of x in radians */
double asin(double x) {
	double asin, term;
	asin = x;
	term = x;
	int n = 1;
	if(x > 1 || x < -1) {
		printf("asin is not defined for this value\n");
		return -1;
	}
	while (!(term >= -0.0000001 && term <= 0.0000001)) {
		term = ((term) * (x * x) * (2 * n - 1) * (2 * n - 1)) / ((2 * n + 1) * (2 * n));
		asin += term;	
		n++;
	}
	return asin;
}

/*This function returns the arc cos of x in radians */
double acos(double x) {
	double acos;
	if(x > 1 || x < -1) {
		printf("acos is not defined for this value\n");
		return -1;
	}
	acos = (PI / 2) - asin(x);
	return acos;
}

/* This function returns the arc tan of x in radians */
double atan(double x) {
	double atan = x;
	double term = x;
	if(x > -1 && x < 1) {
		int n = 1;
		while (!(term >= -0.0000001 && term <= 0.0000001)) {
			term = ((-term) * (x * x) * (2 * n - 1)) / (2 * n + 1);
			atan += term;
			n += 2;
		}
	}
	else if(x >= 1) {
		int n = 1;
		long double temp, term;
		temp = (1 / x);
		term = (1 / x);
		while (!(term >= -0.001 && term <= 0.001)) {
			term = ((-term) * n) / ((x * x) * (n + 2));
			temp = temp + term;
			n += 2;
		}
		atan = (PI / 2) - temp;
	}
	else if(x <= -1) {
		int n = 1;
		long double temp, term;
		temp = (1 / x);
		term = (1 / x);
		while (!(term >= -0.001 && term <= 0.001)) {
			term = ((-term) * n) / ((x * x) * (n + 2));
			temp = temp + term;
			n += 2;
		}
		atan = (-PI / 2) - temp;
	}
	return atan;
}


double fmod(double x, double y) {
	double p;
	p = x;
	if(x >= 0 && y >= 0)
		while(p >= y) {
			p = p - y;
		}
	if(x >= 0 && y < 0)
		while (p >= fabs(y)) {
			p = p + y;
		}
	if(x < 0 && y >= 0)
		while (fabs(p) >= y) {
			p = p + y;
		}
	if(x < 0 && y < 0)
		while (fabs(p) >= fabs(y)) {
			p = p - y;
		}
	return p;
}


double ldexp(double x, int exponent) {
	double a, b, c = exponent;
	a = pow(2, c);
	b = x * a;
	return b;
}


double modf(double x, double *integer) {
	double p;
	*integer = (int)x;
	p = x - *integer;
	return p;
}


double frexp(double x, int *exponent) {
	double p, q;
	p = 1;
	*exponent = 0;
	while(p <= fabs(x)) {
		p = p * 2;
		*exponent = *exponent + 1;
	}
	q = x / p;
	return q;
}


double atan2(double x, double y) {
	double atan2, p;
	if(y == 0 ) {
		if(x >= 0)
			atan2 = 0;
		else if(x < 0)
			atan2 = PI;
	}
	p = (fabs(x) / fabs(y));
	if(x >= 0 && y > 0) {		
		atan2 = atan(p);
	}
	else if(x < 0 && y > 0) {
		atan2 = PI - atan(p);
	}
	else if(x < 0 && y < 0) {
		atan2 = PI + atan(p);
	}
	else if(x >= 0 && y < 0) {
		atan2 = atan(p);
	}
	return atan2; 
}
